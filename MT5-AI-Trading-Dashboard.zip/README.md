# MT5 AI Trading Dashboard
Full rebuild with webhook, Telegram, CI/CD